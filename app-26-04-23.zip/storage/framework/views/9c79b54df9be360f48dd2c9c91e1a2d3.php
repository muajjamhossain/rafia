<?php $__env->startSection('content'); ?>

    <section class="doctors-area">
        <div class="doctors-find">
            <div class="container">
                <div class="row">
                    <div class="col-lg-7 mx-auto">
                        <div class="find-doctors">
                            <div class="h2 fw-bold">Find Our <span class="primary-color">DOCTORS</span></div>
                            <hr>
                            <form action="/" class="row justify-content-center">
                                <div class="col-6">
                                    <input type="text" name="name" placeholder="Search by name">
                                </div>
                                <div class="col-6">
                                    <input type="text" name="name" placeholder="Search by specialty ">
                                </div>
                                <div class="col-lg-6">
                                    <button type="submit">Search</button>

                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="doctors-content">
            <div class="container">
                <div class="row">

                    <?php $__currentLoopData = $allDoctor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $auto = '';
                            if(($key + 1) % 2 ==0){
                                $auto = 'ms-auto';
                            }
                        ?>

                        <div class="col-lg-5 <?php echo e($auto); ?>">
                            <div class="doctors-item">
                                <div class="image">


                                    <?php if($doctor->photo!=''): ?>
                                        <img src="<?php echo e(asset('uploads/doctors/'.$doctor->photo)); ?>" height="200" width="150" alt="doctors images">
                                    <?php else: ?>
                                        
                                        <img src="<?php echo e(asset('assets/website')); ?>/assets/img/doctors-img-1.svg" alt="doctors images">
                                    <?php endif; ?>
                                </div>
                                <div class="text">
                                    <p>
                                        <b class="primary-color"><?php echo e($doctor->name); ?></b>
                                        <br>
                                        <b>Doctors Degree:</b> <?php echo e($doctor->degree); ?>

                                        <br>
                                        <b>Specialties:</b> <?php echo e($doctor->speciality_name); ?>

                                        <br>
                                        <b>Branch:</b> <?php echo e($doctor->branch); ?>

                                        <br>
                                        <b>Practice Days:</b> <?php echo e($doctor->practice_days); ?>

                                    </p>
                                    <div class="get-btn">
                                        <a href="#">Get appointment</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                </div>



                



            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/website', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laragon\www\Rafia\resources\views/website/doctors.blade.php ENDPATH**/ ?>