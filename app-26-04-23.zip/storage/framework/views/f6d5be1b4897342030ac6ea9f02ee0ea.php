
<?php $__env->startSection('content'); ?>
<div class="row bread_part">
    <div class="col-sm-12 bread_col">
        <h4 class="pull-left page-title bread_title">Manage</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Manage</a></li>
            <li class="active">Basic</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(url('dashboard/manage/basic/update')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card">
              <div class="card-header">
                  <div class="row">
                      <div class="col-md-8">
                          <h3 class="card-title card_top_title"><i class="fa fa-gg-circle"></i> Basic Information</h3>
                      </div>
                      <div class="col-md-4 text-right">
                          <a href="<?php echo e(url('dashboard/manage/social')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> Social Media</a>
                      </div>
                      <div class="clearfix"></div>
                  </div>
              </div>
              <div class="card-body card_form">
                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-7">
                        <?php if(Session::has('success')): ?>
                          <div class="alert alert-success alertsuccess" role="alert">
                             <strong>Successfully!</strong> update basic information.
                          </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                          <div class="alert alert-warning alerterror" role="alert">
                             <strong>Opps!</strong> please try again.
                          </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-2"></div>
                </div>
                <div class="form-group row custom_form_group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Title:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="title" value="<?php echo e($basic->basic_title); ?>">
                      <?php if($errors->has('title')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('title')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Subtitle:</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="subtitle" value="<?php echo e($basic->basic_subtitle); ?>">
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Details:</label>
                    <div class="col-sm-7">
                      <textarea class="form-control" rows="3" id="" name="details"><?php echo e($basic->basic_details); ?></textarea>
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Photo:</label>
                    <div class="col-sm-4">
                      <div class="input-group">
                          <span class="input-group-btn">
                              <span class="btn btn-default btn-file btnu_browse">
                                  Browse… <input type="file" name="pic" id="imgInp">
                              </span>
                          </span>
                          <input type="text" class="form-control" readonly>
                      </div>
                      <img id='img-upload'/>
                    </div>
                    <div class="col-sm-2">
                        <img class="img-thumbnail" src="<?php echo e(asset('uploads/basic/'.$basic->basic_logo)); ?>"/>
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Favicon:</label>
                    <div class="col-sm-4">
                      <div class="input-group">
                          <span class="input-group-btn">
                              <span class="btn btn-default btn-file btnu_browse">
                                  Browse… <input type="file" name="favicon" id="imgInpFavicon">
                              </span>
                          </span>
                          <input type="text" class="form-control" readonly>
                      </div>
                      <img id='img-upload-favicon'/>
                    </div>
                    <div class="col-sm-2">
                        <img class="img-thumbnail basic_favicon_img" src="<?php echo e(asset('uploads/basic/'.$basic->basic_favicon)); ?>"/>
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Footer Logo:</label>
                    <div class="col-sm-4">
                      <div class="input-group">
                          <span class="input-group-btn">
                              <span class="btn btn-default btn-file btnu_browse">
                                  Browse… <input type="file" name="flogo" id="imgInpFlogo">
                              </span>
                          </span>
                          <input type="text" class="form-control" readonly>
                      </div>
                      <img id='img-upload-flogo'/>
                    </div>
                    <div class="col-sm-2">
                        <img class="img-thumbnail" src="<?php echo e(asset('uploads/basic/'.$basic->basic_flogo)); ?>"/>
                    </div>
                </div>
              </div>
              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">UPDATE</button>
              </div>
          </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laragon\www\Rafia\resources\views/admin/manage/basic.blade.php ENDPATH**/ ?>