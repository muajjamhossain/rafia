
<?php $__env->startSection('content'); ?>
<div class="row bread_part">
    <div class="col-sm-12 bread_col">
        <h4 class="pull-left page-title bread_title">Appointment</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Appointment</a></li>
            <li class="active">View</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8">
                        <h3 class="card-title card_top_title"><i class="fa fa-gg-circle"></i> View Appointment</h3>
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(url('dashboard/appointment')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> All Appointment</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
                        <table class="table table-bordered table-striped table-hover custom_view_table">
                            <tr>
                                <td>Name</td>
                                <td>:</td>
                                <td><?php echo e($data->name); ?></td>
                            </tr>
                            <tr>
                                <td>Age</td>
                                <td>:</td>
                                <td><?php echo e($data->age); ?></td>
                            </tr>
                            <tr>
                                <td>Gender</td>
                                <td>:</td>
                                <td><?php echo e($data->gender); ?></td>
                            </tr>
                            <tr>
                                <th>patient Status</th>
                                <td>:</td>
                                <td><?php echo e($data->patient_status); ?></td>
                            </tr>
                            <tr>
                                <td>Date</td>
                                <td>:</td>
                                <td><?php echo e($data->schedule_date); ?></td>
                            </tr>
                            <tr>
                                <td>Time</td>
                                <td>:</td>
                                <td><?php echo e($data->schedule_time); ?></td>
                            </tr>
                            <tr>
                                <td>Speciality</td>
                                <td>:</td>
                                <td><?php echo e($data->SpecialityInfo->speciality_name); ?></td>
                            </tr>
                            <tr>
                                <td>Doctor</td>
                                <td>:</td>
                                <td><?php echo e($data->doctorInfo->name); ?></td>
                            </tr>
                            <tr>
                                <td>Description</td>
                                <td>:</td>
                                <td><?php echo e($data->description); ?></td>
                            </tr>
                            <tr>
                                <td>Time</td>
                                <td>:</td>
                                <td><?php echo e($data->created_at->format('d-m-Y | h:i:s a')); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-2"></div>
                </div>
            </div>
            <div class="card-footer card_footer_expode">
                <a href="<?php echo e(url('dashboard/appointment/print/'.$data->slug)); ?>" class="btn btn-secondary waves-effect btnPrint">PRINT</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laragon\www\Rafia\resources\views/admin/appointment/view.blade.php ENDPATH**/ ?>