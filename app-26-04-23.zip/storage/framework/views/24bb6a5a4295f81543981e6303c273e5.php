
<?php $__env->startSection('content'); ?>
<div class="row bread_part">
    <div class="col-sm-12 bread_col">
        <h4 class="pull-left page-title bread_title">Speciality</h4>
        <ol class="breadcrumb pull-right">
            <li><a href="#">Dashboard</a></li>
            <li><a href="#">Speciality</a></li>
            <li class="active">Add</li>
        </ol>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <form class="form-horizontal" method="post" action="<?php echo e(url('dashboard/speciality/submit')); ?>" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="card">
              <div class="card-header">
                  <div class="row">
                      <div class="col-md-8">
                          <h3 class="card-title card_top_title"><i class="fa fa-gg-circle"></i> Add Speciality</h3>
                      </div>
                      <div class="col-md-4 text-right">
                          <a href="<?php echo e(url('dashboard/speciality')); ?>" class="btn btn-md btn-primary waves-effect card_top_button"><i class="fa fa-th"></i> All Speciality</a>
                      </div>
                      <div class="clearfix"></div>
                  </div>
              </div>
              <div class="card-body card_form">
                <div class="row">
                    <div class="col-md-3"></div>
                    <div class="col-md-7">
                        <?php if(Session::has('success')): ?>
                          <div class="alert alert-success alertsuccess" role="alert">
                             <strong>Successfully!</strong> add Speciality information.
                          </div>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                          <div class="alert alert-warning alerterror" role="alert">
                             <strong>Opps!</strong> please try again.
                          </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-2"></div>
                </div>
                <div class="form-group row custom_form_group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Speciality Name:<span class="req_star">*</span></label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>">
                      <?php if($errors->has('name')): ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($errors->first('name')); ?></strong>
                          </span>
                      <?php endif; ?>
                    </div>
                </div>
                <div class="form-group row custom_form_group">
                    <label class="col-sm-3 control-label">Remarks:</label>
                    <div class="col-sm-7">
                      <input type="text" class="form-control" name="remarks" value="<?php echo e(old('remarks')); ?>">
                    </div>
                </div>
              </div>
              <div class="card-footer card_footer_button text-center">
                  <button type="submit" class="btn btn-primary waves-effect">SUBMIT</button>
              </div>
          </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laragon\www\Rafia\resources\views/admin/speciality/add.blade.php ENDPATH**/ ?>